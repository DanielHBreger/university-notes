# Sagnac slide images

Eight main PNG images in numbered order, plus one optional calibration comparison. Each is 1920 × 1080 (16:9). Paste each image onto a blank slide. Explanations and transitions are in presenter_notes.md. No presentation file is included.

The sequence follows the measurement: apparatus and phase prediction, timed rotation calibration, observed ring motion, ring displacement to phase, phase versus rotation, method sensitivity, and speed of light with the uncertainty build-up.

Image 04 has a white central area for an animation you add yourself. Use a rectangle beginning at x = 442 px, y = 119 px, width 1037 px, height 435 px (top-left image coordinates), or fit a smaller animation inside it. Three original stills below it show the same progression. No animation is supplied.

Every main result uses the linear calibration. The quadratic calibration appears only in optional_A1. The phase fit image quotes fit and calibration uncertainty. Image 07 adds the phase-method spread. Image 08 then adds the loop geometry. All displayed uncertainties are standard uncertainties.

Sources and the single consolidated discussion of limitations are in presenter_notes.md. Source data and rebuild code remain in the experiment folder.
